
function login(event) {
  event.preventDefault();
  const user = document.getElementById("username").value;
  const pass = document.getElementById("password").value;
  const status = document.getElementById("loginStatus");

  if (user === "admin" && pass === "1234") {
    status.textContent = "Login successful!";
    status.style.color = "green";
  } else {
    status.textContent = "Invalid credentials.";
    status.style.color = "red";
  }
}
